<?php //myFooter-inc.php

	//#method to hop back along user history....
	echo '</body></html>'; // END html render
