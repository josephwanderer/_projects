<?php #error handling tools
	ini_set('display_errors', 1);
?>