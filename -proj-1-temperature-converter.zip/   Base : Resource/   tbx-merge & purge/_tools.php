

<h1>date and time</h1>
<p>The time is now <?php echo date('H:i:s'); ?></p>
<p>&copy; <?php include 'copyright.php'; ?> Hansel and Petal</p>
